

<h1 align="center">Bachelor Point</h1>
<div align="center">
  <strong>A bachelor friendly site</strong>
</div>
<br>
<div align="center">
  <!-- Release Version -->
    <img src="https://img.shields.io/github/tag/Ahsan40/course-assistant?color=blue&label=Release&style=for-the-badge" alt="Release Version" />
  <!-- Last Updated (Does not show Date, Only month and year)-->
    <!-- <img src="https://img.shields.io/github/release-date/Ahsan40/course-assistant?color=green&label=Updated&style=for-the-badge" alt="Release Date" /> -->
  <!-- Downloads Size -->
    <img src="https://img.shields.io/github/repo-size/Ahsan40/course-assistant?color=orange&label=Size&style=for-the-badge" alt="Downloads Size" />
  <!-- Download counts -->
    <img src="https://img.shields.io/github/downloads/Ahsan40/course-assistant/total?color=green&style=for-the-badge" alt="Download Count" />
</div>


&nbsp;
&nbsp;
## 💠 **Introductions**
  An alrounder helper for bachelors. <sub></sub>

&nbsp;
&nbsp;
## 📜 **Features**
      ● Log in, Sign up with authentication.
      ● User profiles for different types of users
      ● Post for to-let (for general user)
      ● Find and book a room or flat (for general user)
      ● Post for different services (for the service provider)
      ● Find a kitchen maid (for general user)
      ● Finding tuition or jobs (for general user)
      ● Old products shopping system (for general user)    

&nbsp;

## 📜 **Build Setps**
      1. pip install django
      2. pip install pymongo==3.12.3
      3. pip install dnspython
      4. python manage.py makemigrations
      5. pip install smtplib

&nbsp;



&nbsp;
&nbsp;
<!-- 
## ⬇ **Downloads**
</strong>Will be added later</strong>
<br>
<br> -->


